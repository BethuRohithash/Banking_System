package com.cognizant.customer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomersmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
